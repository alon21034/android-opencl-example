/* Copyright (c) 2009-2011 QUALCOMM Incorporated.
 * All Rights Reserved. QUALCOMM Proprietary and Confidential.
 */

/* This file deprecated. It's only provided for backwards compatibility with older applications.
 * New applications are strongly recommended to include cl_ext_qcom.h instead.
 */
#include <CL/cl_ext_qcom.h>

